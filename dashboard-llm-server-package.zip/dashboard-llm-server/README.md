# Dashboard LLM 服务端代码包

## 包含文件

- `server/api/llm.ts` — Express 路由：`/api/llm/providers`、`/api/llm/kimi-coding/chat`、`/v1/chat/completions`
- `server/lib/llm/kimi-coding.ts` — 上游 Kimi Coding API 调用

## 接入方式

```ts
import { registerLlmRoutes } from './server/api/llm.js';

registerLlmRoutes(app);
```

需先 `app.use(express.json())`。

## 环境变量

- `KIMI_CODING_API_KEY`（或 `kimikey`）：调用上游 Kimi 必填
- `LLM_API_TOKEN`：对外 Bearer 鉴权（可选；不设置则不校验）

## 依赖

- `express`
- Node 18+（内置 `fetch`）

编译/运行时使用与项目一致的 ESM 路径（`.js` 扩展名导入）。
