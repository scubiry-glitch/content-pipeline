import type { Express, Request, Response } from 'express';
import { callKimiCodingText, kimiCodingProvider } from '../lib/llm/kimi-coding.js';

function readBearerToken(req: Request): string {
  const auth = String(req.headers.authorization || '').trim();
  if (!auth.toLowerCase().startsWith('bearer ')) return '';
  return auth.slice(7).trim();
}

function isAuthorized(req: Request): boolean {
  const expected = process.env.LLM_API_TOKEN?.trim();
  if (!expected) return true;
  return readBearerToken(req) === expected;
}

function readMaxTokens(raw: unknown): number | undefined {
  if (typeof raw !== 'number' || !Number.isFinite(raw) || raw <= 0) return undefined;
  return Math.floor(raw);
}

function readPromptFromMessages(messages: unknown): string {
  if (!Array.isArray(messages)) return '';
  const userTexts: string[] = [];
  for (const item of messages) {
    if (!item || typeof item !== 'object') continue;
    const role = String((item as { role?: unknown }).role ?? '').trim();
    if (role !== 'user') continue;
    const content = (item as { content?: unknown }).content;
    if (typeof content === 'string') {
      const t = content.trim();
      if (t) userTexts.push(t);
      continue;
    }
    if (!Array.isArray(content)) continue;
    const parts: string[] = [];
    for (const part of content) {
      if (!part || typeof part !== 'object') continue;
      const type = String((part as { type?: unknown }).type ?? '').trim();
      if (type !== 'text') continue;
      const text = String((part as { text?: unknown }).text ?? '').trim();
      if (text) parts.push(text);
    }
    if (parts.length > 0) userTexts.push(parts.join('\n'));
  }
  return userTexts.join('\n').trim();
}

export function registerLlmRoutes(app: Express): void {
  app.get('/api/llm/providers', (_req: Request, res: Response) => {
    const provider = kimiCodingProvider['kimi-coding'];
    res.json({
      status: 'success',
      data: {
        providers: [
          {
            id: 'kimi-coding',
            baseUrl: provider.baseUrl,
            api: provider.api,
            models: provider.models,
          },
        ],
      },
    });
  });

  app.post('/api/llm/kimi-coding/chat', async (req: Request, res: Response) => {
    if (!isAuthorized(req)) {
      return res.status(401).json({
        status: 'error',
        message: 'Unauthorized',
      });
    }

    const prompt = String(req.body?.prompt ?? '').trim();
    if (!prompt) {
      return res.status(400).json({
        status: 'error',
        message: 'prompt 不能为空',
      });
    }

    const model = String(req.body?.model ?? '').trim() || undefined;
    const maxTokens = readMaxTokens(req.body?.maxTokens);

    try {
      const result = await callKimiCodingText(prompt, { model, maxTokens });
      if (!result.ok) {
        return res.status(result.status || 502).json({
          status: 'error',
          message: result.error || 'LLM 调用失败',
          data: {
            provider: 'kimi-coding',
            model: result.model,
            upstreamStatus: result.status,
            raw: result.raw,
          },
        });
      }

      return res.json({
        status: 'success',
        data: {
          provider: 'kimi-coding',
          model: result.model,
          id: result.id,
          reply: result.text,
          raw: result.raw,
        },
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'LLM 调用异常';
      return res.status(500).json({
        status: 'error',
        message,
      });
    }
  });

  app.post('/v1/chat/completions', async (req: Request, res: Response) => {
    if (!isAuthorized(req)) {
      return res.status(401).json({
        error: {
          message: 'Invalid authentication credentials',
          type: 'invalid_request_error',
        },
      });
    }

    const model = String(req.body?.model ?? '').trim() || 'k2p5';
    const maxTokens = readMaxTokens(req.body?.max_tokens) ?? readMaxTokens(req.body?.max_completion_tokens);
    const prompt = readPromptFromMessages(req.body?.messages);
    if (!prompt) {
      return res.status(400).json({
        error: {
          message: 'messages 不能为空，且至少包含一条 user 文本消息',
          type: 'invalid_request_error',
        },
      });
    }

    try {
      const result = await callKimiCodingText(prompt, { model, maxTokens });
      if (!result.ok) {
        return res.status(result.status || 502).json({
          error: {
            message: result.error || 'Upstream model error',
            type: 'upstream_error',
            upstream_status: result.status,
            upstream_raw: result.raw,
          },
        });
      }

      const completionText = result.text || '';
      const now = Math.floor(Date.now() / 1000);
      return res.json({
        id: result.id || `chatcmpl_${Date.now()}`,
        object: 'chat.completion',
        created: now,
        model: result.model,
        choices: [
          {
            index: 0,
            message: {
              role: 'assistant',
              content: completionText,
            },
            finish_reason: 'stop',
          },
        ],
        usage: {
          prompt_tokens: 0,
          completion_tokens: 0,
          total_tokens: 0,
        },
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Internal server error';
      return res.status(500).json({
        error: {
          message,
          type: 'server_error',
        },
      });
    }
  });
}
